# Deterministic evaluation fixture
